package IDS.restful;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringResTfulApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
